var id;
var data1;
var data2;
chrome.runtime.onMessage.addListener((request) => {
	if (request.name === 'start') {
		chrome.tabs.getSelected(tab=>{
			id=tab.id;
			data1=request.ids;
			data2=request.passes;
			chrome.tabs.sendMessage(id,{name:'start',ids:data1,passes:data2});
		});
	};
});