var data=[];

data[0]="exampleID1,examplePASS1";
data[1]="exampleID2,examplePASS2";
data[2]="exampleID3,examplePASS3";

var l=data.length;
var data1=[];
var data2=[];
var i;
for(i=0;i<l;i++){
	data1.push(data[i].split(",")[0]);
	data2.push(data[i].split(",")[1]);
};
chrome.runtime.sendMessage({ name: 'start',ids:data1,passes:data2 });
window.close();

