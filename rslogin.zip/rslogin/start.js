var data=[];
//data[idx]="ID,PASS";
//idx：インデックス（0から
//ID：ログインに必要なID
//PASS：ログインに必要なパスワード
//インデックス0は例です。
data[0]="example_id,example_pass";

var l=data.length;
var data1=[];
var data2=[];
var i;
for(i=0;i<l;i++){
	data1.push(data[i].split(",")[0]);
	data2.push(data[i].split(",")[1]);
};
chrome.runtime.sendMessage({ name: 'start',ids:data1,passes:data2 });
window.close();

