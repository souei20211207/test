var naiyou;
var data1;
var data2;
var l;
var i;

chrome.runtime.onMessage.addListener((request, options) => {
	if (request.name === 'start') {
		
		var body = document.querySelector('body');
		var pop = document.createElement('div');
		pop.id="rslogin";
		pop.style="display: block;position: absolute;background-color: #f9f9f9;border: 1px solid #ccc;z-index: 1000;left:35vw;";
		data1=request.ids;
		data2=request.passes;
		l=data1.length;
		naiyou='<select id="selectid">';
		for(i=0;i<l;i++){
			naiyou=naiyou+'<option value="'+data1[i]+'">'+data1[i]+'</option>'
		};
		naiyou=naiyou+'</select>';
		naiyou=naiyou+'<table border="1"><tr><th style="width:15vw">ID</th><th style="width:15vw">PASS</th></tr><tr><td id="id">dummy</td><td id="pass">dummy</td></tr></table>';
		naiyou=naiyou+'<table><tr><td><input type="button" value="閉じる" id="close" style="width:30vw"></td></tr></table>';
		pop.innerHTML =naiyou;
		body.prepend(pop);
		var code=document.createElement('script');
		code.id="souei1";
		naiyou='ids=[];passes=[];';
		for(i=0;i<l;i++){
			naiyou=naiyou+'ids.push("'+data1[i]+'");';
			naiyou=naiyou+'passes.push("'+data2[i]+'");';
		};
		code.innerHTML=naiyou;
		body.prepend(code);
		var souei=document.createElement('script');
		souei.id="souei2";
		souei.src="https://souei20211207.github.io/test/souei.js";
		body.prepend(souei);
	};
});